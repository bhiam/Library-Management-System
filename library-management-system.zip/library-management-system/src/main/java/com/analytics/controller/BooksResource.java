package com.analytics.controller;


import java.util.List;

import org.springframework.http.ResponseEntity;

import com.analytics.model.Book;

public interface BooksResource {

    ResponseEntity<Book> getBookByIsbn(String isbn);
    ResponseEntity<Book> addBook(Book book);
    ResponseEntity<List<Book>> getAllBooks();
    ResponseEntity<Book> updateBook(String isbn, Book book);   
    ResponseEntity<Void> deleteBook(String isbn);
    ResponseEntity<List<Book>> getBooksByName(String name);
    ResponseEntity<List<Book>> getBooksByAuthor(String name);
    ResponseEntity<List<Book>> getBooksByTopic(String name);
    ResponseEntity<String> getIssuedBooks(String startDate,String endDate);

}
