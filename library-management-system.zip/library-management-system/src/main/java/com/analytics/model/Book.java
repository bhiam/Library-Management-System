package com.analytics.model;

import java.util.Date;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.hateoas.ResourceSupport;
public class Book extends ResourceSupport{

    private String isbn;

    @NotBlank
    private String bookName;

    private String author;
    
    private String topic;
    private String status;
    private String borrower;
    private Date borrowDate;
    private Date returnDate;
    
    public Book() {
    }

	public Book(String isbn, String bookName, String author,
			String topic, String status, String borrower,
			Date borrowDate, Date returnDate) {
        this.isbn = isbn;
        this.bookName = bookName;
        this.author =author;
        this.setTopic(topic);
        this.status = status;
        this.borrower = borrower;
        this.borrowDate = borrowDate;
        this.returnDate = returnDate;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getbookName() {
        return bookName;
    }

    public void setbookName(String bookName) {
        this.bookName = bookName;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }
    
    public String gettopic() {
		return author;
	}

	public void settopic(String topic) {
		this.author = topic;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getBorrower() {
		return borrower;
	}

	public void setBorrower(String borrower) {
		this.borrower = borrower;
	}

	public Date getBorrowDate() {
		return borrowDate;
	}

	public void setBorrowDate(Date borrowDate) {
		this.borrowDate = borrowDate;
	}

	public Date getReturnDate() {
		return returnDate;
	}

	public void setReturnDate(Date returnDate) {
		this.returnDate = returnDate;
	}

    @Override
    public String toString() {
        return "Book{" + "isbn='" + isbn + '\'' + ", bookName='" + bookName + '\'' + '}';
    }

	public String getTopic() {
		return topic;
	}

	public void setTopic(String topic) {
		this.topic = topic;
	}
}
