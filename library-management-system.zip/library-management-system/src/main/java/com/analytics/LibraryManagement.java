package com.analytics;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;

import com.analytics.model.Book;
import com.analytics.model.User;
import com.analytics.repository.BookRepository;
import com.analytics.repository.UsersRepository;

@ComponentScan
@EnableAutoConfiguration
public class LibraryManagement
{
    @Autowired
    private BookRepository booksRepo;
    
    @Autowired
    private UsersRepository usersRepo;


    public static void main( String[] args ){
        SpringApplication.run(LibraryManagement.class, args);

    }

    @PostConstruct
    public void initApplication() throws IOException, ParseException {
        booksRepo.addBook(new Book("111-1","autobiography of a yogi","Yogananda","pbs publisher","Not-Avilable","amit",new SimpleDateFormat("yyyy-MM-dd").parse("2020-08-25"),new SimpleDateFormat("yyyy-MM-dd").parse("31-08-2020")));
        booksRepo.addBook(new Book("111-2","Gita","Lord Krishna","Kbs publisher","Avilable","none",null,null));
        booksRepo.addBook(new Book("111-3","Ramayan","Tulsi das","pbs publisher","Avilable","none",null,null));
        booksRepo.addBook(new Book("111-4","Gita","Iskon","pbs publisher","Avilable","none",null,null));
        booksRepo.addBook(new Book("111-5","shreemad bhagwat geeta","Iskon","pbs publisher","Avilable","none",null,null));
        
        usersRepo.addUser(new User("111-1","amit","Nainital","none","none","none","none"));
        usersRepo.addUser(new User("111-2","amit","Delhi","none","none","none","none"));
        usersRepo.addUser(new User("111-3","Harish","Lucknow","none","none","none","none"));
        
        
    }
}

